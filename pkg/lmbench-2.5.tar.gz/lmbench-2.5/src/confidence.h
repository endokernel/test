#ifndef _CONFIDENCE_H
#define _CONFIDENCE_H

double ci_width(double var, int n);

#endif /* _CONFIDENCE_H */
