#define	MAJOR	2
#define	MINOR	5	/* negative is alpha, it "increases" */
