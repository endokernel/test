.. highlightlang:: c

.. _krb5-ui4-struct:

krb5_ui_4
==========

..
.. c:type:: krb5_ui_4
..

krb5_ui_4 is an unsigned 32-bit integer type.
